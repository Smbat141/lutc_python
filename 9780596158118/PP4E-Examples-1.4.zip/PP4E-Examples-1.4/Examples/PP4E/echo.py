print('Spam')
input('press Enter')
