The scripts here are Python 2.X code which uses the mysq-python
(mysqldb) interface to the MySQL database system.  Because this
system was not available for Python 3.X when the 4th edition of
the book was written (June 2010), SQLite was used instead, though
the Python portable dabatase API makes the examples applicable to
other systems as well.

See the Documentation directory here for the 3rd Edition's 
MySql material.