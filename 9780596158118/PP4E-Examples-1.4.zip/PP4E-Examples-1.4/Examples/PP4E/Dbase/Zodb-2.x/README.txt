The scripts here are Python 2.X code that uses the ZODB object 
database system.  They appeared in the 3rd Edition of the book 
but not in the 4th, because ZODB was not yet available for 
Python 3.X as when the book was updated (June 2010).

See the Documentation directory here for the 3rd Edition's 
ZODB material.
