import time
for i in range(1, 10, 2):
    time.sleep(2)                   # print to standard output
    print('spam' * i)               # nothing GUI about this, eh?
