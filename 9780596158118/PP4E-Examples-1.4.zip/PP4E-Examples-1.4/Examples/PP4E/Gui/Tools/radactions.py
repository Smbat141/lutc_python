# callback handlers: reloaded each time triggered

def message1():                 # change me
    print('spamSpamSPAM')       # or could build a dialog...

def message2(self):
    print('Ni! Ni!')            # change me
    self.method1()              # access the 'Hello' instance...
