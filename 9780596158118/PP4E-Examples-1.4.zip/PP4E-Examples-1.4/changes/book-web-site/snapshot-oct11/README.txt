This is a snapshot of the portions of my book support website
related to this book, as of Oct-19-2011:

   index.html         --books site root page
   about-pp4e.html    --this book's root page (probably start here)
   pp4e-updates.html  --this book's updates page (or here)

The book updates page includes supplemental examples, Python
updates, and book notes.  Some update pages for the book 
Learning Python 4th Ed are also included, as they are linked.

For the latest news, visit the live page at 
    http://www.rmi.net/~lutz/about-pp4e.html.
  