This is a snapshot of the portions of my book support website
related to this book, as of Feb-24-2011:

   index.html         --site root page
   about-pp4e.html    --book root page (probaly start here)
   pp4e-updates.html  --book updates page

The book updates page includes supplemental examples, Python
updates, and book notes.  For the latest news, visit the live
page at http://www.rmi.net/~lutz/about-pp4e.html.
  