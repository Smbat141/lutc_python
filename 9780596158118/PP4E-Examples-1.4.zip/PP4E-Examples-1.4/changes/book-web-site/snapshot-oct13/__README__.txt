Various recent pages and supplemental examples from 
the book support website at:

    http://www.rmi.net/~lutz

