Audio files deleted -- place 3 files here, and name
them in the main script.