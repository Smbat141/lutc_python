Various Chapter 6 admin script results:
--diffall does a byte-for-byte directory tree compare
--visitor_sloc runs a tree source-code file/line count
--cleanpyc finds and deletes and pyc bytecode files 