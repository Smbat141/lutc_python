Note, July 2012: some unzip tools might botch the Unicode
(non-ASCII) names of the files in this directory.  This 
appears to include the Windows 7 handler for zip files in
its file manager which you'll get by default if you click 
on the icon of the book examples package zip file.

The WinZip program, at www.winzip.com, handles such files
correctly, and can be downloaded for a free trial period.
Python itself comes with a zip library module which may 
or may not handle non-ASCII file names in archives (to 
be tested).
