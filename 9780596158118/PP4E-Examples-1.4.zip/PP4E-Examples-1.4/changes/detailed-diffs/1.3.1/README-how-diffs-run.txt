# per the book's updates page, the first line is needed to 
# avoid Unicode filename printing errors for non-ASCII files
# added as tests in the PyMailGUI media directory.

c:\...\PP4E\System\Filetools> set PYTHONIOENCODING=utf-8

c:\..\PP4E\System\Filetools> c:\python31\python diffall.py 
   D:\Books\4E\PP4E\examples-official\1.3\unpacked\PP4E-Examples-1.3 
   D:\Books\4E\PP4E\examples-official\1.3.1\PP4E-Examples-1.3.1 
 > D:\Books\4E\PP4E\examples-official\1.3.1\PP4E-Examples-1.3.1\changes\detailed-diffs\1.3.1\diffall.txt

